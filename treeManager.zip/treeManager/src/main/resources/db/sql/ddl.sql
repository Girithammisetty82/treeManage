--DROP TABLE users IF EXISTS;
create table NodePojo 
	(id varchar(255) not null, 
	 description varchar(255) not null, 
	 lft integer not null, name varchar(255) not null, 
	 rgt integer not null, 
	 topLevel_id varchar(255), 
	 primary key (id));
	 
alter table NodePojo add constraint FKj00f80fc3xorhe6us0vwl83kx foreign key (topLevel_id) references NodePojo;

