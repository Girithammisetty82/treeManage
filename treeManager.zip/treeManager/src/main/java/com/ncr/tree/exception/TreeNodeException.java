package com.ncr.tree.exception;

public class TreeNodeException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public TreeNodeException(String message) {
		super(message);
	}

	public TreeNodeException(String message, Throwable cause) {
		super(message, cause);
	}

}
