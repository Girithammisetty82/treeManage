package com.ncr.tree.api.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ncr.domain.NodeWrapper;
import com.ncr.jpa.tree.repository.TreeRepository;

@RestController
@RequestMapping(value = "/tree/node")
public class TreeManageController extends AbstractRestHandler {

	private static final Logger logger = LoggerFactory.getLogger(TreeManageController.class);
	@Autowired
	TreeRepository treeRepository;

	@RequestMapping(value = "/addRoot", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> createNode(@RequestBody NodeWrapper nodeWrapper) throws Exception {
		logger.debug("createNode start.......");
		ResponseEntity<?> responseEntity = null;

		treeRepository.createRootNode(nodeWrapper.getParentNode());
		responseEntity = new ResponseEntity<String>("SUCCESS :: Root Node added.", HttpStatus.OK);
		log.info("Tree root node CREATED : ");

		return responseEntity;
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> addNode(@RequestBody NodeWrapper nodeWrapper) throws Exception {
		logger.debug("addNode start.......");
		ResponseEntity<?> responseEntity = null;
		if (nodeWrapper.getNodePoistion() > 0) {
			treeRepository.addNode(nodeWrapper.getParentNode(), nodeWrapper.getNode(),
					nodeWrapper.getNodePoistion());
			responseEntity = new ResponseEntity<String>("SUCCESS :: Added Node at given position.", HttpStatus.OK);
		} else {
			treeRepository.addNode(nodeWrapper.getParentNode(), nodeWrapper.getNode());
			responseEntity = new ResponseEntity<String>("SUCCESS :: Added Nod.", HttpStatus.OK);
			
		}
		
		log.info("addNode end ");

		return responseEntity;
	}

	@RequestMapping(value = "/findAllChildren", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> getNodeChildren(@RequestBody NodeWrapper nodeWrapper) throws Exception {
		logger.debug("getNodeChildren start.......");
		ResponseEntity<?> responseEntity = new ResponseEntity<>(treeRepository.getAllChildrens(nodeWrapper.getNode()),
				HttpStatus.OK);
		log.info("getNodeChildren end ..");
		return responseEntity;
	}

	@RequestMapping(value = "/find", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> getNode(@RequestBody NodeWrapper nodeWrapper) throws Exception {
		logger.debug("getNodeChildren start.......");
		ResponseEntity<?> responseEntity = new ResponseEntity<>(treeRepository.getNode(nodeWrapper.getNode()),
				HttpStatus.OK);
		log.info("getNodeChildren end ..");
		return responseEntity;
	}
	@RequestMapping(value = "/remove", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> removeNode(@RequestBody NodeWrapper nodeWrapper) throws Exception {
		logger.debug("remove node start.......");
		ResponseEntity<?> responseEntity = null;

		treeRepository.removeNode(nodeWrapper.getNode());
		responseEntity = new ResponseEntity<String>("SUCCESS :: Removed node and its children.", HttpStatus.OK);
		log.info("Node removed ");

		return responseEntity;
	}
}
