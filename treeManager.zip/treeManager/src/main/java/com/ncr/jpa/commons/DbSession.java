package com.ncr.jpa.commons;

import java.io.Serializable;
import java.util.List;


public interface DbSession
{

	Object get(Class<?> entityClass, Serializable id);
	List<?> queryList(String queryText, Object [] parameters);
	int queryCount(String queryText, Object [] parameters);

	Object save(Object node);
	

	void refresh(Object node);
	
	void delete(Object node);

	void executeUpdate(String statement, Object [] parameters);
	
	void flush();
	
}
