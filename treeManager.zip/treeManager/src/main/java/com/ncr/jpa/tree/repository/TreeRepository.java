package com.ncr.jpa.tree.repository;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ncr.domain.NodePojo;
import com.ncr.jpa.commons.DbSessionJpaImpl;
import com.ncr.jpa.tree.nested.NestedSetsTreeDao;
import com.ncr.jpa.tree.nested.NestedSetsTreeNode;
import com.ncr.jpa.tree.nested.uniqueconstraints.UniqueWholeTreeConstraintImpl;
import com.ncr.jpa.tree.uniqueconstraints.UniqueConstraintViolationException;

@Repository
@Transactional
public class TreeRepository {

	@Autowired
	DbSessionJpaImpl dbSessionJpaImpl;

	/**
	 * createRootNode
	 * 
	 * @param node
	 * @throws UniqueConstraintViolationException
	 */
	public void createRootNode(NodePojo node) throws UniqueConstraintViolationException {

		final NestedSetsTreeDao dao = createDao();
		dao.createRoot(node);

	}

	/**
	 * addNode
	 * 
	 * @param paretNode
	 * @param childNode
	 * @throws Exception 
	 */
	public void addNode(NodePojo paretNode, NodePojo childNode) throws Exception {

		NestedSetsTreeDao dao = createDao();
		final Map<String, Object> criteria = new Hashtable<String, Object>();
		criteria.put("name", paretNode.getName());
		NestedSetsTreeNode pNode = dao.findRoot(paretNode, criteria).get(0);
		if(dao.getChildCount(pNode) <=15){
			dao.addChild(pNode, childNode);
		}else{
			throw new Exception("Children size more than 15.");
		}
		
	}

	/**
	 * addNode
	 * 
	 * @param paretNode
	 * @param childNode
	 * @throws Exception 
	 */
	public void addNode(NodePojo paretNode, NodePojo childNode, int position)
			throws Exception {

		NestedSetsTreeDao dao = createDao();
		final Map<String, Object> criteria = new Hashtable<String, Object>();
		criteria.put("name", paretNode.getName());
		NestedSetsTreeNode pNode = dao.findRoot(paretNode, criteria).get(0);
		if(dao.getChildCount(pNode) <=15){
			dao.addChildAt(pNode, childNode, position);
		}else{
			throw new Exception("Children size more than 15.");
		}
		
	}

	/**
	 * getNode
	 * 
	 * @param node
	 * @return
	 * @throws UniqueConstraintViolationException
	 */
	public NestedSetsTreeNode getNode(NodePojo node) throws UniqueConstraintViolationException {
		NestedSetsTreeDao dao = createDao();
		final Map<String, Object> criteria = new Hashtable<String, Object>();
		criteria.put("name", node.getName());
		final List<NestedSetsTreeNode> result = dao.find(node, criteria);
		if (result != null && result.size() > 0 && result.get(0) != null) {
			return result.get(0);
		}

		return null;
	}

	/**
	 * getNodeChildren
	 * 
	 * @param node
	 * @return
	 * @throws UniqueConstraintViolationException
	 */
	public List<NestedSetsTreeNode> getNodeChildren(NodePojo node) throws UniqueConstraintViolationException {
		NestedSetsTreeDao dao = createDao();
		List<NestedSetsTreeNode> result = null;
		Map<String, Object> criteria = new Hashtable<String, Object>();
		criteria.put("name", node.getName());
		result = dao.find(node, criteria);
		if (result != null && result.size() > 0 && result.get(0) != null) {
			result = dao.getChildren(result.get(0));
		}
		return result;
	}

	/**
	 * getNodeAllChildren
	 * 
	 * @param node
	 * @return
	 * @throws UniqueConstraintViolationException
	 */
	public List<NestedSetsTreeNode> getAllChildrens(NodePojo node) throws UniqueConstraintViolationException {
		NestedSetsTreeDao dao = createDao();
		List<NestedSetsTreeNode> result = null;
		Map<String, Object> criteria = new Hashtable<String, Object>();
		criteria.put("name", node.getName());
		result = dao.find(node, criteria);
		if (result != null && result.size() > 0 && result.get(0) != null) {
			result = dao.getTree(result.get(0));
		}

		return result;
	}

	/**
	 * getNodePath
	 * 
	 * @param node
	 * @return
	 * @throws UniqueConstraintViolationException
	 */
	public List<NestedSetsTreeNode> getNodePath(NodePojo node) throws UniqueConstraintViolationException {
		NestedSetsTreeDao dao = createDao();
		List<NestedSetsTreeNode> result = null;
		Map<String, Object> criteria = new Hashtable<String, Object>();
		criteria.put("name", node.getName());
		result = dao.find(node, criteria);
		if (result != null && result.size() > 0 && result.get(0) != null) {
			result = dao.getPath(result.get(0));

		}
		return result;
	}

	/**
	 * removeNode
	 * 
	 * @param node
	 * @throws UniqueConstraintViolationException
	 */
	public void removeNode(NodePojo node) throws Exception {
		NestedSetsTreeDao dao = createDao();
		List<NestedSetsTreeNode> result = null;
		Map<String, Object> criteria = new Hashtable<String, Object>();
		criteria.put("name", node.getName());
		result = dao.find(node, criteria);
		if (result != null && result.size() > 0 && result.get(0) != null) {
			if(dao.isRoot(result.get(0))){
				throw new Exception("Cannot remove Root node.");
			}else{
			dao.remove(result.get(0));
			}
		}
	}

	private NestedSetsTreeDao createDao() {
		NestedSetsTreeDao dao = new NestedSetsTreeDao(NodePojo.class, dbSessionJpaImpl);
		dao.setUniqueTreeConstraint(new UniqueWholeTreeConstraintImpl(new String[][] { { "name" } }, false));
		return dao;
	}

}