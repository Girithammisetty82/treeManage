package com.ncr.domain;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class NodeWrapper {

	private int nodePoistion=0;
	private NodePojo node;
	private NodePojo parentNode;

	public int getNodePoistion() {
		return nodePoistion;
	}

	public NodePojo getNode() {
		return node;
	}

	public NodePojo getParentNode() {
		return parentNode;
	}

	public void setNodePoistion(int nodePoistion) {
		this.nodePoistion = nodePoistion;
	}

	public void setNode(NodePojo node) {
		this.node = node;
	}

	public void setParentNode(NodePojo parentNode) {
		this.parentNode = parentNode;
	}

}
