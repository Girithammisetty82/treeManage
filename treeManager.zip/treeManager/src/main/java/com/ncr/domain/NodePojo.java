package com.ncr.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.ncr.jpa.tree.nested.NestedSetsTreeNode;


@Entity
@Table(name = "NodePojo")
@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true) 
@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class, property="@id")
public class NodePojo implements NestedSetsTreeNode
{

	@Id @GeneratedValue(generator="system-uuid")
	@GenericGenerator(name="system-uuid", strategy = "uuid")
	private String id;

	@Column(nullable = false)
	private String name;
	
	@Column(nullable = false)
	private String description;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@ManyToOne(targetEntity = NodePojo.class)
	private NestedSetsTreeNode topLevel; // root reference

	private int lft; // "left" would be a SQL keyword!
	private int rgt; // "right" would be a SQL keyword!

    
	public NodePojo() {
	}

	public NodePojo(String name,String description) {
		this.name = name;
		this.description=description;
	}

	@Override
	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}


	// NestedSetsTreeNode
	
	@Override
	public NestedSetsTreeNode getTopLevel() {
		return topLevel;
	}
	@Override
	public void setTopLevel(NestedSetsTreeNode topLevel) {
		this.topLevel = topLevel;
	}

	@Override
	public int getLeft() {
		return lft;
	}
	@Override
	public void setLeft(int left) {
		this.lft = left;
	}

	@Override
	public int getRight() {
		return rgt;
	}
	@Override
	public void setRight(int right) {
		this.rgt = right;
	}

	// Cloneable
	
	@Override
	public NodePojo clone() {
		return new NodePojo(getName(),getDescription());
	}
	
	// others
	
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof NodePojo == false)
			return false;

		if (id != null)
			return id.equals(((NodePojo) obj).getId());

		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		if (id != null)
			return id.hashCode();

		throw new IllegalStateException("Do not use hashCode() with tranisent POJOs, they could get lost in Maps!");
	}

	/** Overridden to avoid super.toString() calling hashCode(), as this might throw exception when no id exists yet. */
	@Override
	public String toString() {
		return getClass().getSimpleName()+"@"+System.identityHashCode(this)+": id="+getId()+", name="+getName()+", description="+ getDescription();
	}

}